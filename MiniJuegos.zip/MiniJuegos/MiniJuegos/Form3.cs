﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MiniJuegos
{
    public partial class Form3 : Form
    {
        public Form3()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void btnjugar_Click(object sender, EventArgs e)
        {
            Ppt juego2 = new Ppt();

            int mano = juego2.generarAleatorio();
            int eleccion = cbmano.SelectedIndex;

            Jugador jugador = new Jugador();
            jugador.Nombre = lbjugador.Text;
            jugador.Total = int.Parse(lbtotal.Text);
            if ((mano == 0) && (eleccion == 0))
            {
                pbmano.Image = Image.FromFile("piedra.jpg");
                lbtotal.Text = jugador.aumentarTotal(int.Parse(txtapuesta.Text)).ToString();
                MessageBox.Show("Salio piedra. Ganaste!" + eleccion + mano);
            }
            else if ((mano == 0) && (eleccion == 1))
            {
                pbmano.Image = Image.FromFile("papel.jpg");
                lbtotal.Text = jugador.aumentarTotal(int.Parse(txtapuesta.Text)).ToString();
                MessageBox.Show("Salio papel. Ganaste!" + eleccion + mano);
            }
            else if ((mano == 1) && (eleccion == 1))
            {
                pbmano.Image = Image.FromFile("tijera.jpg");
                lbtotal.Text = jugador.aumentarTotal(int.Parse(txtapuesta.Text)).ToString();
                MessageBox.Show("Salio tijera. Ganaste!" + eleccion + mano);
            }
            else if ((mano == 1) && (eleccion == 0))
            {
                pbmano.Image = Image.FromFile("piedra.jpg");
                lbtotal.Text = jugador.aumentarTotal(int.Parse(txtapuesta.Text)).ToString();
                MessageBox.Show("Salio piedra. perdiste" + eleccion + mano);
            }
            else if ((mano == 0) && (eleccion == 2))
            {
                pbmano.Image = Image.FromFile("papel.jpg");
                lbtotal.Text = jugador.aumentarTotal(int.Parse(txtapuesta.Text)).ToString();
                MessageBox.Show("Salio papel. perdiste" + eleccion + mano);
            }
            else if ((mano == 2) && (eleccion == 0))
            {
                pbmano.Image = Image.FromFile("tijera.jpg");
                lbtotal.Text = jugador.aumentarTotal(int.Parse(txtapuesta.Text)).ToString();
                MessageBox.Show("Salio tijera. perdiste" + eleccion + mano);
            }
        }

        private void pbmano_Click(object sender, EventArgs e)
        {

        }
    }
}

