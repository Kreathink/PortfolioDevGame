﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MiniJuegos
{
    internal class Craps : IJuego
    {
        public void finalizarJuego()
        {
            throw new NotImplementedException();
        }

        public int generarAleatorio()
        {
            Random dado = new Random();

            return dado.Next(0, 7);

            Random dado2 = new Random();

            return dado2.Next(0, 7);

        }
    }

}

