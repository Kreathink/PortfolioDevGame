﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MiniJuegos
{
    public class Ppt: IJuego
    {
        public void finalizarJuego()
        {
            throw new NotImplementedException();
        }

        public int generarAleatorio()
        {
            Random mano = new Random();

            return mano.Next(0, 3);

        }
    }
}
