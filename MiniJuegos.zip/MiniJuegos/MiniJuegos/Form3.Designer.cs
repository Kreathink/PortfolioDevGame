﻿namespace MiniJuegos
{
    partial class Form3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }
        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form3));
            this.lbjugador = new System.Windows.Forms.Label();
            this.lbtotal = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.cbmano = new System.Windows.Forms.ComboBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.txtapuesta = new System.Windows.Forms.TextBox();
            this.btnjugar = new System.Windows.Forms.Button();
            this.pbmano = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pbmano)).BeginInit();
            this.SuspendLayout();
            // 
            // lbjugador
            // 
            this.lbjugador.AutoSize = true;
            this.lbjugador.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lbjugador.Location = new System.Drawing.Point(474, 38);
            this.lbjugador.Name = "lbjugador";
            this.lbjugador.Size = new System.Drawing.Size(70, 21);
            this.lbjugador.TabIndex = 0;
            this.lbjugador.Text = "jugador";
            // 
            // lbtotal
            // 
            this.lbtotal.AutoSize = true;
            this.lbtotal.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lbtotal.Location = new System.Drawing.Point(474, 71);
            this.lbtotal.Name = "lbtotal";
            this.lbtotal.Size = new System.Drawing.Size(46, 21);
            this.lbtotal.TabIndex = 1;
            this.lbtotal.Text = "total";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label1.Location = new System.Drawing.Point(389, 38);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(79, 19);
            this.label1.TabIndex = 2;
            this.label1.Text = "Jugador:";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // cbmano
            // 
            this.cbmano.FormattingEnabled = true;
            this.cbmano.Items.AddRange(new object[] {
            "Piedra",
            "Papel",
            "Tijera"});
            this.cbmano.Location = new System.Drawing.Point(79, 69);
            this.cbmano.Name = "cbmano";
            this.cbmano.Size = new System.Drawing.Size(173, 23);
            this.cbmano.TabIndex = 3;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Century Gothic", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label2.Location = new System.Drawing.Point(79, 32);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(255, 23);
            this.label2.TabIndex = 4;
            this.label2.Text = "Elija: piedra, papel o tijera";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Century Gothic", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label3.Location = new System.Drawing.Point(79, 121);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(245, 23);
            this.label3.TabIndex = 5;
            this.label3.Text = "Ingrese el valor a apostar";
            // 
            // txtapuesta
            // 
            this.txtapuesta.BackColor = System.Drawing.Color.GhostWhite;
            this.txtapuesta.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtapuesta.Location = new System.Drawing.Point(82, 170);
            this.txtapuesta.Name = "txtapuesta";
            this.txtapuesta.Size = new System.Drawing.Size(170, 23);
            this.txtapuesta.TabIndex = 6;
            // 
            // btnjugar
            // 
            this.btnjugar.BackColor = System.Drawing.Color.Aqua;
            this.btnjugar.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btnjugar.Location = new System.Drawing.Point(203, 239);
            this.btnjugar.Name = "btnjugar";
            this.btnjugar.Size = new System.Drawing.Size(195, 43);
            this.btnjugar.TabIndex = 7;
            this.btnjugar.Text = "Apostar";
            this.btnjugar.UseVisualStyleBackColor = false;
            this.btnjugar.Click += new System.EventHandler(this.btnjugar_Click);
            // 
            // pbmano
            // 
            this.pbmano.BackColor = System.Drawing.Color.Honeydew;
            this.pbmano.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pbmano.ErrorImage = null;
            this.pbmano.InitialImage = null;
            this.pbmano.Location = new System.Drawing.Point(474, 121);
            this.pbmano.Name = "pbmano";
            this.pbmano.Size = new System.Drawing.Size(189, 174);
            this.pbmano.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbmano.TabIndex = 8;
            this.pbmano.TabStop = false;
            this.pbmano.Click += new System.EventHandler(this.pbmano_Click);
            // 
            // Form3
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.pbmano);
            this.Controls.Add(this.btnjugar);
            this.Controls.Add(this.txtapuesta);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.cbmano);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.lbtotal);
            this.Controls.Add(this.lbjugador);
            this.Name = "Form3";
            this.Text = "Juego Piedra, papel o tijera";
            ((System.ComponentModel.ISupportInitialize)(this.pbmano)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        public Label label2;
        private ComboBox cbmano;
        public Label label3;
        private TextBox txtapuesta;
        private Button btnjugar;
        public Label label1;
        public Label lbjugador;
        public Label lbtotal;
        private PictureBox pbmano;
    }
}