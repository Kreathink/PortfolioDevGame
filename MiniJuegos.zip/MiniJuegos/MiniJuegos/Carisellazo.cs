﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MiniJuegos
{
    public class Carisellazo : IJuego
    {
        public void finalizarJuego()
        {
            throw new NotImplementedException();
        }

        public int generarAleatorio()
        {
            Random moneda = new Random();

            return moneda.Next(0, 2);

        }
    }

}
