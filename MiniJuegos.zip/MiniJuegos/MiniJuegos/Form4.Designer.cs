﻿namespace MiniJuegos
{
    partial class Form4
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }


        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form4));
            this.label1 = new System.Windows.Forms.Label();
            this.txtapuesta = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.pbdado = new System.Windows.Forms.PictureBox();
            this.pbdado2 = new System.Windows.Forms.PictureBox();
            this.btnjugar = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.lbjugador = new System.Windows.Forms.Label();
            this.lbtotal = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.pbdado)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbdado2)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label1.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label1.Location = new System.Drawing.Point(53, 20);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(210, 30);
            this.label1.TabIndex = 0;
            this.label1.Text = "Craps: a un solo tiro";
            // 
            // txtapuesta
            // 
            this.txtapuesta.Location = new System.Drawing.Point(53, 119);
            this.txtapuesta.Name = "txtapuesta";
            this.txtapuesta.Size = new System.Drawing.Size(146, 23);
            this.txtapuesta.TabIndex = 1;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label2.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label2.Location = new System.Drawing.Point(53, 73);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(201, 21);
            this.label2.TabIndex = 2;
            this.label2.Text = "Ingrese el valor a apostar";
            // 
            // pbdado
            // 
            this.pbdado.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pbdado.ErrorImage = null;
            this.pbdado.InitialImage = null;
            this.pbdado.Location = new System.Drawing.Point(373, 199);
            this.pbdado.Name = "pbdado";
            this.pbdado.Size = new System.Drawing.Size(189, 174);
            this.pbdado.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbdado.TabIndex = 9;
            this.pbdado.TabStop = false;
            // 
            // pbdado2
            // 
            this.pbdado2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pbdado2.ErrorImage = null;
            this.pbdado2.InitialImage = null;
            this.pbdado2.Location = new System.Drawing.Point(590, 20);
            this.pbdado2.Name = "pbdado2";
            this.pbdado2.Size = new System.Drawing.Size(189, 174);
            this.pbdado2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbdado2.TabIndex = 10;
            this.pbdado2.TabStop = false;
            // 
            // btnjugar
            // 
            this.btnjugar.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.btnjugar.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btnjugar.Location = new System.Drawing.Point(53, 173);
            this.btnjugar.Name = "btnjugar";
            this.btnjugar.Size = new System.Drawing.Size(195, 43);
            this.btnjugar.TabIndex = 11;
            this.btnjugar.Text = "Apostar";
            this.btnjugar.UseVisualStyleBackColor = false;
            this.btnjugar.Click += new System.EventHandler(this.btnjugar_Click_1);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label3.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label3.Location = new System.Drawing.Point(291, 28);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(79, 19);
            this.label3.TabIndex = 12;
            this.label3.Text = "Jugador:";
            // 
            // lbjugador
            // 
            this.lbjugador.AutoSize = true;
            this.lbjugador.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lbjugador.Location = new System.Drawing.Point(376, 27);
            this.lbjugador.Name = "lbjugador";
            this.lbjugador.Size = new System.Drawing.Size(70, 21);
            this.lbjugador.TabIndex = 13;
            this.lbjugador.Text = "jugador";
            // 
            // lbtotal
            // 
            this.lbtotal.AutoSize = true;
            this.lbtotal.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lbtotal.Location = new System.Drawing.Point(376, 60);
            this.lbtotal.Name = "lbtotal";
            this.lbtotal.Size = new System.Drawing.Size(46, 21);
            this.lbtotal.TabIndex = 14;
            this.lbtotal.Text = "total";
            // 
            // Form4
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.lbtotal);
            this.Controls.Add(this.lbjugador);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.btnjugar);
            this.Controls.Add(this.pbdado2);
            this.Controls.Add(this.pbdado);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.txtapuesta);
            this.Controls.Add(this.label1);
            this.Name = "Form4";
            this.Text = "Craps: a un solo tiro";
            this.Load += new System.EventHandler(this.Form4_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pbdado)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbdado2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Label label1;
        private TextBox txtapuesta;
        private Label label2;
        private PictureBox pbdado;
        private PictureBox pbdado2;
        private Button btnjugar;
        public Label label3;
        public Label lbjugador;
        public Label lbtotal;
    }
}