﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MiniJuegos
{
    public partial class Form4 : Form
    {
        public Form4()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void btnjugar_Click(object sender, EventArgs e)
        {
            

        }

        private void Form4_Load(object sender, EventArgs e)
        {

        }

        private void btnjugar_Click_1(object sender, EventArgs e)
        {
            Craps juego1 = new Craps();
            Craps juego2 = new Craps();
            Jugador jugador = new Jugador();
            jugador.Nombre = lbjugador.Text;
            jugador.Total = int.Parse(lbtotal.Text);


            int dado = juego1.generarAleatorio();
            int dado2 = juego1.generarAleatorio();
            int total = dado + dado2;

            
            if (dado == 1 && dado2 == 1)
            {
                pbdado.Image = Image.FromFile("1.jpg");
                pbdado2.Image = Image.FromFile("1.jpg");
                lbtotal.Text = jugador.aumentarTotal(int.Parse(txtapuesta.Text)).ToString();
                MessageBox.Show("Un par de 1 en los dados. Ganaste!" + dado + dado2);
            }
            else if (total == 3)
            {
                pbdado.Image = Image.FromFile("1.jpg");
                pbdado2.Image = Image.FromFile("2.jpg");
                lbtotal.Text = jugador.aumentarTotal(int.Parse(txtapuesta.Text)).ToString();
                MessageBox.Show("Un total de 3 en los dados. Ganaste!" + dado + dado2);
            }
            else if (total == 11)
            {
                pbdado.Image = Image.FromFile("6.jpg");
                pbdado2.Image = Image.FromFile("5.jpg");
                lbtotal.Text = jugador.aumentarTotal(int.Parse(txtapuesta.Text)).ToString();
                MessageBox.Show("Un total de 11 en los dados. Ganaste!" + dado + dado2);
            }
            else if (total == 12)
            {
                pbdado.Image = Image.FromFile("6.jpg");
                pbdado2.Image = Image.FromFile("6.jpg");
                lbtotal.Text = jugador.aumentarTotal(int.Parse(txtapuesta.Text)).ToString();
                MessageBox.Show("Un total de 12 en los dados. Ganaste!" + dado + dado2);
            }
            else if (total == 2 || total == 12)
            {
                pbdado.Image = Image.FromFile("1.jpg");
                pbdado2.Image = Image.FromFile("1.jpg");
                pbdado.Image = Image.FromFile("6.jpg");
                pbdado2.Image = Image.FromFile("6.jpg");
                lbtotal.Text = jugador.aumentarTotal(int.Parse(txtapuesta.Text)).ToString();
                MessageBox.Show("Un total de 2 en los dados. Ganaste!" + dado + dado2);
            }
            else if (total == 7)
            {
                pbdado.Image = Image.FromFile("5.jpg");
                pbdado2.Image = Image.FromFile("2.jpg");
                lbtotal.Text = jugador.aumentarTotal(int.Parse(txtapuesta.Text)).ToString();
                MessageBox.Show("Un total de once en los dados. Ganaste!" + dado + dado2);
            }
            else
            {
                MessageBox.Show("No tienes craps :( Perdiste" + dado + dado2);
            }
        }
    }
}
