﻿namespace MiniJuegos
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.txtnombre = new System.Windows.Forms.TextBox();
            this.txttotal = new System.Windows.Forms.TextBox();
            this.lbjugador = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.btnentrar = new System.Windows.Forms.Button();
            this.btnentrar1 = new System.Windows.Forms.Button();
            this.btnentrar2 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // txtnombre
            // 
            this.txtnombre.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtnombre.Location = new System.Drawing.Point(479, 160);
            this.txtnombre.Name = "txtnombre";
            this.txtnombre.Size = new System.Drawing.Size(200, 23);
            this.txtnombre.TabIndex = 0;
            // 
            // txttotal
            // 
            this.txttotal.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txttotal.Location = new System.Drawing.Point(479, 215);
            this.txttotal.Name = "txttotal";
            this.txttotal.Size = new System.Drawing.Size(200, 23);
            this.txttotal.TabIndex = 1;
            // 
            // lbjugador
            // 
            this.lbjugador.AutoSize = true;
            this.lbjugador.BackColor = System.Drawing.Color.Transparent;
            this.lbjugador.Font = new System.Drawing.Font("Century Gothic", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lbjugador.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.lbjugador.Location = new System.Drawing.Point(143, 158);
            this.lbjugador.Name = "lbjugador";
            this.lbjugador.Size = new System.Drawing.Size(321, 25);
            this.lbjugador.TabIndex = 2;
            this.lbjugador.Text = "Ingrese el nombre del jugador";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Century Gothic", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label1.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label1.Location = new System.Drawing.Point(143, 210);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(264, 25);
            this.label1.TabIndex = 3;
            this.label1.Text = "Ingrese el total a apostar";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // btnentrar
            // 
            this.btnentrar.BackColor = System.Drawing.Color.Yellow;
            this.btnentrar.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btnentrar.Location = new System.Drawing.Point(41, 310);
            this.btnentrar.Name = "btnentrar";
            this.btnentrar.Size = new System.Drawing.Size(174, 47);
            this.btnentrar.TabIndex = 4;
            this.btnentrar.Text = "Jugar Cara y Sello";
            this.btnentrar.UseVisualStyleBackColor = false;
            this.btnentrar.Click += new System.EventHandler(this.btnentrar_Click);
            // 
            // btnentrar1
            // 
            this.btnentrar1.BackColor = System.Drawing.Color.Yellow;
            this.btnentrar1.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btnentrar1.Location = new System.Drawing.Point(249, 310);
            this.btnentrar1.Name = "btnentrar1";
            this.btnentrar1.Size = new System.Drawing.Size(232, 47);
            this.btnentrar1.TabIndex = 5;
            this.btnentrar1.Text = "Jugar piedra, papel o tijera ";
            this.btnentrar1.UseVisualStyleBackColor = false;
            this.btnentrar1.Click += new System.EventHandler(this.btnentrar1_Click_1);
            // 
            // btnentrar2
            // 
            this.btnentrar2.BackColor = System.Drawing.Color.Yellow;
            this.btnentrar2.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btnentrar2.Location = new System.Drawing.Point(514, 310);
            this.btnentrar2.Name = "btnentrar2";
            this.btnentrar2.Size = new System.Drawing.Size(232, 47);
            this.btnentrar2.TabIndex = 6;
            this.btnentrar2.Text = "Jugar craps: tiro al dado";
            this.btnentrar2.UseVisualStyleBackColor = false;
            this.btnentrar2.Click += new System.EventHandler(this.button1_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnentrar2);
            this.Controls.Add(this.btnentrar1);
            this.Controls.Add(this.btnentrar);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.lbjugador);
            this.Controls.Add(this.txttotal);
            this.Controls.Add(this.txtnombre);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Aplicación de Juegos";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private TextBox txtnombre;
        private TextBox txttotal;
        private Label lbjugador;
        private Label label1;
        private Button btnentrar;
        private Button btnentrar1;
        private Button btnentrar2;
    }
}