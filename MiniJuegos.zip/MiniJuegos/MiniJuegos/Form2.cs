﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MiniJuegos
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void btnjugar_Click(object sender, EventArgs e)
        {
            Carisellazo juego1 = new Carisellazo();

            int moneda = juego1.generarAleatorio();
            int eleccion = cbmoneda.SelectedIndex;

            Jugador jugador = new Jugador();
            jugador.Nombre = lbjugador.Text;
            jugador.Total = int.Parse(lbtotal.Text);

            if (moneda == 0 && eleccion == 0)
            {
               pbmoneda.Image = Image.FromFile("cara.png");
                lbtotal.Text = jugador.aumentarTotal(int.Parse(txtapuesta.Text)).ToString();
                MessageBox.Show("Escogiste Cara, salió la cara Ganaste!" + eleccion + moneda);


            }
            else if (moneda == 0 && eleccion == 1)
            {
                pbmoneda.Image = Image.FromFile("cara.png");
                //Disminuir total
                MessageBox.Show("Escogiste Sello, salió cara Perdiste!" + eleccion + moneda);

            }
            else if (moneda == 1 && eleccion == 1)
            {
                pbmoneda.Image = Image.FromFile("sello.png");
                lbtotal.Text = jugador.aumentarTotal(int.Parse(txtapuesta.Text)).ToString();
                MessageBox.Show("Escogiste Sello, salió sello Ganaste!" + eleccion + moneda);

            }
            else if (moneda == 1 && eleccion == 0)
            {
                pbmoneda.Image = Image.FromFile("sello.png");
                MessageBox.Show("Escogiste Cara, salió sello Perdiste!" + eleccion + moneda);

            }

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void Form2_Load(object sender, EventArgs e)
        {

        }

        private void pbmoneda_Click(object sender, EventArgs e)
        {

        }
    }
}