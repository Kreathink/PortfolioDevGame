﻿namespace MiniJuegos
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void btnentrar_Click(object sender, EventArgs e)
        {
            Form2 f2 = new Form2();
            f2.lbjugador.Text = txtnombre.Text;
            f2.lbtotal.Text = txttotal.Text;


            //Ocultar formulario 1 e ir al carisellazo
            Form.ActiveForm.Visible = false;
            f2.Show();
        }
        private void btnentrar1_Click(object sender, EventArgs e)
        {
           
        }
        private void btnentrar2_Click(object sender, EventArgs e)
        {
            
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Form4 f4 = new Form4();
            f4.lbjugador.Text = txtnombre.Text;
            f4.lbtotal.Text = txttotal.Text;


            //Ocultar formulario 3 e ir a craps 
            Form.ActiveForm.Visible = false;
            f4.Show();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void btnentrar1_Click_1(object sender, EventArgs e)
        {
            Form3 f3 = new Form3();
            f3.lbjugador.Text = txtnombre.Text;
            f3.lbtotal.Text = txttotal.Text;


            //Ocultar formulario 2 e ir a piedra papel o tijera 
            Form.ActiveForm.Visible = false;
            f3.Show();
        }
    }
   }

